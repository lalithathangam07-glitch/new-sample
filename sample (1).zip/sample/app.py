import streamlit as st
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from modules.nlp_scene_parser import SceneParser
from modules.image_generator import ImageGenerator
from modules.three_d_generator import ThreeDGenerator
from modules.audio_generator import AudioGenerator
from modules.scene_manager import SceneManager
from utils.helpers import validate_story_input, truncate_text

st.set_page_config(
    page_title="Story2Scene - AI Story Visualizer",
    page_icon="🎬",
    layout="wide",
    initial_sidebar_state="expanded"
)

st.markdown("""
<style>
    .main-header {
        font-size: 2.5rem;
        font-weight: bold;
        background: linear-gradient(90deg, #667eea 0%, #764ba2 100%);
        -webkit-background-clip: text;
        -webkit-text-fill-color: transparent;
        text-align: center;
        margin-bottom: 1rem;
    }
    .scene-card {
        background: #1e1e2e;
        border-radius: 10px;
        padding: 1rem;
        margin: 0.5rem 0;
        border: 1px solid #333;
    }
    .stats-box {
        background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        border-radius: 10px;
        padding: 1rem;
        color: white;
        text-align: center;
    }
    .timeline-item {
        padding: 0.5rem;
        border-left: 3px solid #667eea;
        margin: 0.5rem 0;
        padding-left: 1rem;
    }
    .timeline-item.active {
        border-left-color: #00ff00;
        background: rgba(102, 126, 234, 0.1);
    }
</style>
""", unsafe_allow_html=True)

def init_session_state():
    if 'story_text' not in st.session_state:
        st.session_state.story_text = ""
    if 'parsed_data' not in st.session_state:
        st.session_state.parsed_data = None
    if 'scenes' not in st.session_state:
        st.session_state.scenes = []
    if 'current_scene_idx' not in st.session_state:
        st.session_state.current_scene_idx = 0
    if 'generated_images' not in st.session_state:
        st.session_state.generated_images = {}
    if 'generated_audio' not in st.session_state:
        st.session_state.generated_audio = {}
    if 'generated_3d' not in st.session_state:
        st.session_state.generated_3d = {}
    if 'generated_animations' not in st.session_state:
        st.session_state.generated_animations = {}
    if 'full_audio_path' not in st.session_state:
        st.session_state.full_audio_path = None
    if 'art_style' not in st.session_state:
        st.session_state.art_style = "realistic"
    if 'voice_option' not in st.session_state:
        st.session_state.voice_option = "en-us"
    if 'generation_complete' not in st.session_state:
        st.session_state.generation_complete = False

init_session_state()

scene_parser = SceneParser()
image_generator = ImageGenerator()
three_d_generator = ThreeDGenerator()
audio_generator = AudioGenerator()
scene_manager = SceneManager()

def render_sidebar():
    with st.sidebar:
        st.markdown("### Settings")
        
        st.session_state.art_style = st.selectbox(
            "Art Style",
            options=["realistic", "anime", "cartoon"],
            index=["realistic", "anime", "cartoon"].index(st.session_state.art_style)
        )
        
        voices = audio_generator.get_available_voices()
        voice_keys = list(voices.keys())
        voice_labels = [voices[k] for k in voice_keys]
        current_idx = voice_keys.index(st.session_state.voice_option) if st.session_state.voice_option in voice_keys else 0
        
        selected_voice_label = st.selectbox(
            "Narration Voice",
            options=voice_labels,
            index=current_idx
        )
        st.session_state.voice_option = voice_keys[voice_labels.index(selected_voice_label)]
        
        st.markdown("---")
        st.markdown("### Project Stats")
        
        if st.session_state.scenes:
            col1, col2 = st.columns(2)
            with col1:
                st.metric("Scenes", len(st.session_state.scenes))
            with col2:
                st.metric("Images", len(st.session_state.generated_images))
            
            col3, col4 = st.columns(2)
            with col3:
                st.metric("Audio", len(st.session_state.generated_audio))
            with col4:
                st.metric("3D Renders", len(st.session_state.generated_3d))
        
        st.markdown("---")
        st.markdown("### Quick Actions")
        
        if st.button("Clear All", use_container_width=True):
            for key in ['parsed_data', 'scenes', 'generated_images', 
                       'generated_audio', 'generated_3d', 'generated_animations',
                       'full_audio_path']:
                if key in st.session_state:
                    if isinstance(st.session_state[key], dict):
                        st.session_state[key] = {}
                    elif isinstance(st.session_state[key], list):
                        st.session_state[key] = []
                    else:
                        st.session_state[key] = None
            st.session_state.story_text = ""
            st.session_state.current_scene_idx = 0
            st.session_state.generation_complete = False
            st.rerun()
        
        st.markdown("---")
        st.markdown("### About")
        st.markdown("""
        **Story2Scene** transforms your stories into 
        multi-modal content:
        - 2D Scene Images
        - 3D Renders & Animations
        - Audio Narration
        """)

def render_story_input():
    st.markdown('<p class="main-header">Story2Scene</p>', unsafe_allow_html=True)
    st.markdown("<p style='text-align: center; color: #888;'>Transform your stories into visual scenes, 3D renders, and audio narration</p>", unsafe_allow_html=True)
    
    st.markdown("### Enter Your Story")
    
    sample_story = """Once upon a time in a mystical forest, there lived a young wizard named Elena. She had discovered an ancient spellbook hidden beneath an old oak tree.

One morning, Elena ventured deep into the forest to practice her new spells. The trees whispered secrets as she walked along the winding path.

Suddenly, she encountered a magnificent dragon resting by a crystal-clear lake. The dragon's scales shimmered like emeralds in the sunlight.

"Fear not, young wizard," the dragon spoke with a voice like thunder. "I have been waiting for someone worthy to learn the ancient magic."

Together, they began a journey that would change the kingdom forever. Elena learned the dragon's wisdom, and in return, she shared the joy of friendship."""
    
    story_text = st.text_area(
        "Paste or type your story here:",
        value=st.session_state.story_text if st.session_state.story_text else "",
        height=250,
        placeholder="Enter your story text here... The system will automatically detect scenes, characters, and locations."
    )
    
    col1, col2, col3 = st.columns([1, 1, 1])
    
    with col1:
        if st.button("Load Sample Story", use_container_width=True):
            st.session_state.story_text = sample_story
            st.rerun()
    
    with col2:
        generate_btn = st.button("Generate All Content", type="primary", use_container_width=True)
    
    with col3:
        if st.button("Analyze Story Only", use_container_width=True):
            if story_text.strip():
                st.session_state.story_text = story_text
                with st.spinner("Analyzing story..."):
                    validation = validate_story_input(story_text)
                    if validation["valid"]:
                        parsed = scene_parser.parse_story(story_text)
                        st.session_state.parsed_data = parsed
                        st.session_state.scenes = parsed.get("scenes", [])
                        scene_manager.initialize_project(story_text, parsed)
                        st.success(f"Found {len(st.session_state.scenes)} scenes!")
                    else:
                        st.error("\n".join(validation["errors"]))
                st.rerun()
    
    if generate_btn and story_text.strip():
        st.session_state.story_text = story_text
        generate_all_content(story_text)

def generate_all_content(story_text: str):
    validation = validate_story_input(story_text)
    if not validation["valid"]:
        st.error("\n".join(validation["errors"]))
        return
    
    progress_bar = st.progress(0)
    status_text = st.empty()
    error_container = st.empty()
    errors_occurred = []
    
    try:
        status_text.text("Analyzing story structure...")
        parsed = scene_parser.parse_story(story_text)
        st.session_state.parsed_data = parsed
        st.session_state.scenes = parsed.get("scenes", [])
        scene_manager.initialize_project(story_text, parsed)
        progress_bar.progress(10)
    except Exception as e:
        st.error(f"Failed to analyze story: {str(e)}")
        return
    
    total_scenes = len(st.session_state.scenes)
    
    if total_scenes == 0:
        st.warning("No scenes could be extracted from the story. Please try a longer or more detailed story.")
        return
    
    for i, scene in enumerate(st.session_state.scenes):
        scene_id = scene.get("id", i+1)
        
        try:
            status_text.text(f"Generating 2D image for scene {scene_id}/{total_scenes}...")
            image_path = image_generator.generate_scene_image(scene, st.session_state.art_style)
            st.session_state.generated_images[scene_id] = image_path
            scene_manager.update_scene_assets(scene_id, image_path=image_path)
        except Exception as e:
            errors_occurred.append(f"2D image scene {scene_id}: {str(e)}")
        progress_bar.progress(10 + int((i + 1) / total_scenes * 25))
    
    for i, scene in enumerate(st.session_state.scenes):
        scene_id = scene.get("id", i+1)
        
        try:
            status_text.text(f"Generating 3D render for scene {scene_id}/{total_scenes}...")
            render_path = three_d_generator.generate_3d_render(scene)
            st.session_state.generated_3d[scene_id] = render_path
            scene_manager.update_scene_assets(scene_id, render_3d_path=render_path)
        except Exception as e:
            errors_occurred.append(f"3D render scene {scene_id}: {str(e)}")
        
        try:
            status_text.text(f"Generating animation for scene {scene_id}/{total_scenes}...")
            anim_path = three_d_generator.save_animation_gif(scene)
            st.session_state.generated_animations[scene_id] = anim_path
            scene_manager.update_scene_assets(scene_id, animation_path=anim_path)
        except Exception as e:
            errors_occurred.append(f"Animation scene {scene_id}: {str(e)}")
        progress_bar.progress(35 + int((i + 1) / total_scenes * 25))
    
    for i, scene in enumerate(st.session_state.scenes):
        scene_id = scene.get("id", i+1)
        
        try:
            status_text.text(f"Generating narration for scene {scene_id}/{total_scenes}...")
            audio_path = audio_generator.generate_scene_narration(scene, st.session_state.voice_option)
            if audio_path:
                st.session_state.generated_audio[scene_id] = audio_path
                scene_manager.update_scene_assets(scene_id, audio_path=audio_path)
        except Exception as e:
            errors_occurred.append(f"Audio scene {scene_id}: {str(e)}")
        progress_bar.progress(60 + int((i + 1) / total_scenes * 25))
    
    try:
        status_text.text("Generating full story narration...")
        full_audio = audio_generator.generate_full_story_narration(story_text, st.session_state.voice_option)
        st.session_state.full_audio_path = full_audio
    except Exception as e:
        errors_occurred.append(f"Full story audio: {str(e)}")
    progress_bar.progress(90)
    
    status_text.text("Finalizing...")
    progress_bar.progress(100)
    
    st.session_state.generation_complete = True
    status_text.empty()
    progress_bar.empty()
    
    if errors_occurred:
        with error_container:
            st.warning(f"Generation completed with {len(errors_occurred)} warning(s). Some assets may not have been generated.")
            with st.expander("View Details"):
                for err in errors_occurred:
                    st.text(f"- {err}")
    else:
        st.success("All content generated successfully!")
    st.rerun()

def render_scene_navigator():
    if not st.session_state.scenes:
        return
    
    st.markdown("### Scene Navigator")
    
    scenes = st.session_state.scenes
    scene_options = [f"Scene {s.get('id', i+1)}: {truncate_text(s.get('text', ''), 40)}" 
                    for i, s in enumerate(scenes)]
    
    col1, col2, col3 = st.columns([1, 3, 1])
    
    with col1:
        if st.button("◀ Previous", use_container_width=True):
            if st.session_state.current_scene_idx > 0:
                st.session_state.current_scene_idx -= 1
                st.rerun()
    
    with col2:
        selected = st.selectbox(
            "Select Scene",
            options=range(len(scenes)),
            format_func=lambda x: scene_options[x],
            index=st.session_state.current_scene_idx,
            label_visibility="collapsed"
        )
        if selected != st.session_state.current_scene_idx:
            st.session_state.current_scene_idx = selected
            st.rerun()
    
    with col3:
        if st.button("Next ▶", use_container_width=True):
            if st.session_state.current_scene_idx < len(scenes) - 1:
                st.session_state.current_scene_idx += 1
                st.rerun()
    
    st.markdown(f"**Scene {st.session_state.current_scene_idx + 1} of {len(scenes)}**")
    
    progress = (st.session_state.current_scene_idx + 1) / len(scenes)
    st.progress(progress)

def render_current_scene():
    if not st.session_state.scenes:
        st.info("Enter a story above and click 'Generate All Content' to begin.")
        return
    
    scene = st.session_state.scenes[st.session_state.current_scene_idx]
    scene_id = scene.get("id", st.session_state.current_scene_idx + 1)
    
    st.markdown(f"## Scene {scene_id}")
    
    with st.expander("Scene Text", expanded=True):
        st.write(scene.get("text", ""))
    
    info_col1, info_col2, info_col3 = st.columns(3)
    
    with info_col1:
        st.markdown("**Characters:**")
        chars = scene.get("characters", [])
        if chars:
            for char in chars[:5]:
                st.markdown(f"- {char}")
        else:
            st.markdown("_No characters detected_")
    
    with info_col2:
        st.markdown("**Locations:**")
        locs = scene.get("locations", [])
        if locs:
            for loc in locs[:5]:
                st.markdown(f"- {loc}")
        else:
            st.markdown("_No locations detected_")
    
    with info_col3:
        st.markdown("**Actions:**")
        actions = scene.get("actions", [])
        if actions:
            for action in actions[:5]:
                st.markdown(f"- {action}")
        else:
            st.markdown("_No actions detected_")
    
    st.markdown("---")
    
    tab1, tab2, tab3, tab4 = st.tabs(["2D Image", "3D Render", "Animation", "Audio"])
    
    with tab1:
        if scene_id in st.session_state.generated_images:
            image_path = st.session_state.generated_images[scene_id]
            if os.path.exists(image_path):
                st.image(image_path, caption=f"Scene {scene_id} - {st.session_state.art_style.title()} Style")
                
                with open(image_path, "rb") as f:
                    st.download_button(
                        "Download 2D Image",
                        data=f.read(),
                        file_name=f"scene_{scene_id}_2d.png",
                        mime="image/png"
                    )
        else:
            st.info("2D image not generated yet. Click 'Generate All Content' to create.")
            if st.button("Generate 2D Image Only", key=f"gen_2d_{scene_id}"):
                with st.spinner("Generating..."):
                    path = image_generator.generate_scene_image(scene, st.session_state.art_style)
                    st.session_state.generated_images[scene_id] = path
                st.rerun()
    
    with tab2:
        if scene_id in st.session_state.generated_3d:
            render_path = st.session_state.generated_3d[scene_id]
            if os.path.exists(render_path):
                st.image(render_path, caption=f"3D Render - Scene {scene_id}")
                
                with open(render_path, "rb") as f:
                    st.download_button(
                        "Download 3D Render",
                        data=f.read(),
                        file_name=f"scene_{scene_id}_3d.png",
                        mime="image/png"
                    )
        else:
            st.info("3D render not generated yet.")
            if st.button("Generate 3D Render Only", key=f"gen_3d_{scene_id}"):
                with st.spinner("Generating 3D render..."):
                    path = three_d_generator.generate_3d_render(scene)
                    st.session_state.generated_3d[scene_id] = path
                st.rerun()
    
    with tab3:
        if scene_id in st.session_state.generated_animations:
            anim_path = st.session_state.generated_animations[scene_id]
            if os.path.exists(anim_path):
                st.image(anim_path, caption=f"Animation - Scene {scene_id}")
                
                with open(anim_path, "rb") as f:
                    st.download_button(
                        "Download Animation (GIF)",
                        data=f.read(),
                        file_name=f"scene_{scene_id}_animation.gif",
                        mime="image/gif"
                    )
        else:
            st.info("Animation not generated yet.")
            if st.button("Generate Animation Only", key=f"gen_anim_{scene_id}"):
                with st.spinner("Generating animation..."):
                    path = three_d_generator.save_animation_gif(scene)
                    st.session_state.generated_animations[scene_id] = path
                st.rerun()
    
    with tab4:
        if scene_id in st.session_state.generated_audio:
            audio_path = st.session_state.generated_audio[scene_id]
            if os.path.exists(audio_path):
                st.audio(audio_path, format="audio/mp3")
                
                with open(audio_path, "rb") as f:
                    st.download_button(
                        "Download Scene Audio (MP3)",
                        data=f.read(),
                        file_name=f"scene_{scene_id}_narration.mp3",
                        mime="audio/mp3"
                    )
        else:
            st.info("Audio narration not generated yet.")
            if st.button("Generate Audio Only", key=f"gen_audio_{scene_id}"):
                with st.spinner("Generating audio..."):
                    path = audio_generator.generate_scene_narration(scene, st.session_state.voice_option)
                    if path:
                        st.session_state.generated_audio[scene_id] = path
                st.rerun()

def render_full_story_section():
    if not st.session_state.generation_complete:
        return
    
    st.markdown("---")
    st.markdown("### Full Story Narration")
    
    if st.session_state.full_audio_path and os.path.exists(st.session_state.full_audio_path):
        st.audio(st.session_state.full_audio_path, format="audio/mp3")
        
        with open(st.session_state.full_audio_path, "rb") as f:
            st.download_button(
                "Download Full Story Audio (MP3)",
                data=f.read(),
                file_name="full_story_narration.mp3",
                mime="audio/mp3",
                use_container_width=True
            )

def render_download_section():
    if not st.session_state.generation_complete:
        return
    
    st.markdown("---")
    st.markdown("### Download All Content")
    
    col1, col2 = st.columns(2)
    
    with col1:
        st.markdown("**Individual Downloads:**")
        
        if st.session_state.generated_images:
            st.markdown(f"- {len(st.session_state.generated_images)} 2D Images available")
        if st.session_state.generated_3d:
            st.markdown(f"- {len(st.session_state.generated_3d)} 3D Renders available")
        if st.session_state.generated_animations:
            st.markdown(f"- {len(st.session_state.generated_animations)} Animations available")
        if st.session_state.generated_audio:
            st.markdown(f"- {len(st.session_state.generated_audio)} Audio files available")
    
    with col2:
        if st.button("Export All as ZIP", use_container_width=True):
            with st.spinner("Creating ZIP archive..."):
                for scene_id, path in st.session_state.generated_images.items():
                    scene_manager.update_scene_assets(scene_id, image_path=path)
                for scene_id, path in st.session_state.generated_3d.items():
                    scene_manager.update_scene_assets(scene_id, render_3d_path=path)
                for scene_id, path in st.session_state.generated_animations.items():
                    scene_manager.update_scene_assets(scene_id, animation_path=path)
                for scene_id, path in st.session_state.generated_audio.items():
                    scene_manager.update_scene_assets(scene_id, audio_path=path)
                
                zip_path = scene_manager.export_project_zip()
                
                if os.path.exists(zip_path):
                    with open(zip_path, "rb") as f:
                        st.download_button(
                            "Download ZIP File",
                            data=f.read(),
                            file_name="story2scene_export.zip",
                            mime="application/zip",
                            use_container_width=True
                        )
                    st.success("ZIP file created successfully!")

def render_story_analysis():
    if not st.session_state.parsed_data:
        return
    
    with st.expander("Story Analysis", expanded=False):
        parsed = st.session_state.parsed_data
        
        col1, col2, col3 = st.columns(3)
        
        with col1:
            st.metric("Total Scenes", len(parsed.get("scenes", [])))
        with col2:
            st.metric("Characters Found", len(parsed.get("all_characters", [])))
        with col3:
            st.metric("Locations Found", len(parsed.get("all_locations", [])))
        
        st.markdown("**All Characters:**")
        chars = parsed.get("all_characters", [])
        if chars:
            st.write(", ".join(chars))
        else:
            st.write("_No characters detected_")
        
        st.markdown("**All Locations:**")
        locs = parsed.get("all_locations", [])
        if locs:
            st.write(", ".join(locs))
        else:
            st.write("_No locations detected_")

def main():
    render_sidebar()
    
    render_story_input()
    
    if st.session_state.scenes:
        st.markdown("---")
        render_story_analysis()
        render_scene_navigator()
        render_current_scene()
        render_full_story_section()
        render_download_section()

if __name__ == "__main__":
    main()
