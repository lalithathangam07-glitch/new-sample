import os
import json
from typing import Dict, Any, List, Optional
from datetime import datetime
import shutil
import zipfile


class SceneManager:
    def __init__(self, output_base: str = "output"):
        self.output_base = output_base
        self.images_dir = os.path.join(output_base, "images")
        self.audio_dir = os.path.join(output_base, "audio")
        self.animations_dir = os.path.join(output_base, "animations")
        
        os.makedirs(self.images_dir, exist_ok=True)
        os.makedirs(self.audio_dir, exist_ok=True)
        os.makedirs(self.animations_dir, exist_ok=True)
        
        self.scenes: List[Dict[str, Any]] = []
        self.timeline: List[Dict[str, Any]] = []
        self.metadata: Dict[str, Any] = {}
    
    def initialize_project(self, story_text: str, parsed_data: Dict[str, Any]):
        self.metadata = {
            "created_at": datetime.now().isoformat(),
            "story_preview": story_text[:200] + "..." if len(story_text) > 200 else story_text,
            "total_scenes": len(parsed_data.get("scenes", [])),
            "characters": parsed_data.get("all_characters", []),
            "locations": parsed_data.get("all_locations", [])
        }
        
        self.scenes = parsed_data.get("scenes", [])
        
        self.timeline = []
        for scene in self.scenes:
            self.timeline.append({
                "scene_id": scene.get("id"),
                "text_preview": scene.get("text", "")[:100],
                "image_path": None,
                "render_3d_path": None,
                "animation_path": None,
                "audio_path": None,
                "generated": False
            })
    
    def update_scene_assets(self, scene_id: int, 
                           image_path: Optional[str] = None,
                           render_3d_path: Optional[str] = None,
                           animation_path: Optional[str] = None,
                           audio_path: Optional[str] = None):
        for item in self.timeline:
            if item["scene_id"] == scene_id:
                if image_path:
                    item["image_path"] = image_path
                if render_3d_path:
                    item["render_3d_path"] = render_3d_path
                if animation_path:
                    item["animation_path"] = animation_path
                if audio_path:
                    item["audio_path"] = audio_path
                
                item["generated"] = any([
                    item["image_path"],
                    item["render_3d_path"],
                    item["animation_path"],
                    item["audio_path"]
                ])
                break
    
    def get_scene_by_id(self, scene_id: int) -> Optional[Dict[str, Any]]:
        for scene in self.scenes:
            if scene.get("id") == scene_id:
                return scene
        return None
    
    def get_timeline_item(self, scene_id: int) -> Optional[Dict[str, Any]]:
        for item in self.timeline:
            if item["scene_id"] == scene_id:
                return item
        return None
    
    def get_all_images(self) -> List[str]:
        images = []
        for item in self.timeline:
            if item.get("image_path") and os.path.exists(item["image_path"]):
                images.append(item["image_path"])
        return images
    
    def get_all_audio(self) -> List[str]:
        audio_files = []
        for item in self.timeline:
            if item.get("audio_path") and os.path.exists(item["audio_path"]):
                audio_files.append(item["audio_path"])
        return audio_files
    
    def get_all_animations(self) -> List[str]:
        animations = []
        for item in self.timeline:
            if item.get("animation_path") and os.path.exists(item["animation_path"]):
                animations.append(item["animation_path"])
        return animations
    
    def get_all_3d_renders(self) -> List[str]:
        renders = []
        for item in self.timeline:
            if item.get("render_3d_path") and os.path.exists(item["render_3d_path"]):
                renders.append(item["render_3d_path"])
        return renders
    
    def export_project_zip(self, filename: str = "story2scene_export.zip") -> str:
        zip_path = os.path.join(self.output_base, filename)
        
        with zipfile.ZipFile(zip_path, 'w', zipfile.ZIP_DEFLATED) as zipf:
            for image in self.get_all_images():
                if os.path.exists(image):
                    arcname = os.path.join("images", os.path.basename(image))
                    zipf.write(image, arcname)
            
            for audio in self.get_all_audio():
                if os.path.exists(audio):
                    arcname = os.path.join("audio", os.path.basename(audio))
                    zipf.write(audio, arcname)
            
            for anim in self.get_all_animations():
                if os.path.exists(anim):
                    arcname = os.path.join("animations", os.path.basename(anim))
                    zipf.write(anim, arcname)
            
            for render in self.get_all_3d_renders():
                if os.path.exists(render):
                    arcname = os.path.join("3d_renders", os.path.basename(render))
                    zipf.write(render, arcname)
            
            metadata = {
                "metadata": self.metadata,
                "scenes": self.scenes,
                "timeline": self.timeline
            }
            zipf.writestr("project_data.json", json.dumps(metadata, indent=2))
        
        return zip_path
    
    def get_project_summary(self) -> Dict[str, Any]:
        return {
            "total_scenes": len(self.scenes),
            "images_generated": len(self.get_all_images()),
            "audio_generated": len(self.get_all_audio()),
            "animations_generated": len(self.get_all_animations()),
            "renders_3d_generated": len(self.get_all_3d_renders()),
            "characters": self.metadata.get("characters", []),
            "locations": self.metadata.get("locations", []),
            "created_at": self.metadata.get("created_at", "Unknown")
        }
    
    def cleanup_all(self):
        for directory in [self.images_dir, self.audio_dir, self.animations_dir]:
            if os.path.exists(directory):
                for filename in os.listdir(directory):
                    filepath = os.path.join(directory, filename)
                    try:
                        if os.path.isfile(filepath):
                            os.remove(filepath)
                    except Exception as e:
                        print(f"Error removing {filepath}: {e}")
        
        self.scenes = []
        self.timeline = []
        self.metadata = {}
    
    def get_navigation_data(self) -> List[Dict[str, Any]]:
        nav_data = []
        for i, item in enumerate(self.timeline):
            scene = self.get_scene_by_id(item["scene_id"])
            nav_data.append({
                "index": i,
                "scene_id": item["scene_id"],
                "title": f"Scene {item['scene_id']}",
                "preview": item["text_preview"],
                "has_image": bool(item.get("image_path")),
                "has_audio": bool(item.get("audio_path")),
                "has_animation": bool(item.get("animation_path")),
                "has_3d": bool(item.get("render_3d_path")),
                "characters": scene.get("characters", []) if scene else []
            })
        return nav_data
