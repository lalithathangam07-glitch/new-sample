from PIL import Image, ImageDraw, ImageFont, ImageFilter
import numpy as np
import hashlib
import os
from typing import Dict, Any, List, Tuple
import random
import math


class ImageGenerator:
    def __init__(self, output_dir: str = "output/images"):
        self.output_dir = output_dir
        os.makedirs(output_dir, exist_ok=True)
        
        self.styles = {
            "realistic": {
                "colors": [(70, 130, 180), (34, 139, 34), (210, 180, 140), (135, 206, 235)],
                "bg_gradient": True,
                "edge_softness": 0.3
            },
            "anime": {
                "colors": [(255, 182, 193), (135, 206, 250), (255, 218, 185), (221, 160, 221)],
                "bg_gradient": False,
                "edge_softness": 0.1
            },
            "cartoon": {
                "colors": [(255, 99, 71), (50, 205, 50), (255, 215, 0), (138, 43, 226)],
                "bg_gradient": False,
                "edge_softness": 0.0
            }
        }
        
        self.location_colors = {
            "forest": [(34, 139, 34), (0, 100, 0), (85, 107, 47)],
            "ocean": [(0, 105, 148), (0, 191, 255), (70, 130, 180)],
            "mountain": [(105, 105, 105), (139, 137, 137), (169, 169, 169)],
            "city": [(128, 128, 128), (169, 169, 169), (192, 192, 192)],
            "castle": [(139, 69, 19), (160, 82, 45), (205, 133, 63)],
            "desert": [(237, 201, 175), (210, 180, 140), (244, 164, 96)],
            "night": [(25, 25, 112), (0, 0, 139), (72, 61, 139)],
            "default": [(135, 206, 235), (176, 224, 230), (173, 216, 230)]
        }
    
    def _get_deterministic_seed(self, text: str) -> int:
        return int(hashlib.md5(text.encode()).hexdigest()[:8], 16)
    
    def _detect_setting(self, scene: Dict[str, Any]) -> str:
        text = scene.get("text", "").lower()
        locations = [loc.lower() for loc in scene.get("locations", [])]
        
        setting_keywords = {
            "forest": ["forest", "woods", "tree", "jungle"],
            "ocean": ["ocean", "sea", "beach", "water", "river", "lake"],
            "mountain": ["mountain", "hill", "cliff", "peak"],
            "city": ["city", "town", "street", "building", "urban"],
            "castle": ["castle", "palace", "kingdom", "throne"],
            "desert": ["desert", "sand", "dune"],
            "night": ["night", "dark", "moon", "stars", "midnight"]
        }
        
        for setting, keywords in setting_keywords.items():
            for keyword in keywords:
                if keyword in text or any(keyword in loc for loc in locations):
                    return setting
        
        return "default"
    
    def _create_gradient_background(self, width: int, height: int, colors: List[Tuple[int, int, int]]) -> Image.Image:
        img = Image.new('RGB', (width, height))
        pixels = img.load()
        
        color1, color2 = colors[0], colors[-1]
        
        for y in range(height):
            ratio = y / height
            r = int(color1[0] * (1 - ratio) + color2[0] * ratio)
            g = int(color1[1] * (1 - ratio) + color2[1] * ratio)
            b = int(color1[2] * (1 - ratio) + color2[2] * ratio)
            
            for x in range(width):
                pixels[x, y] = (r, g, b)
        
        return img
    
    def _draw_sun_or_moon(self, draw: ImageDraw.Draw, width: int, height: int, is_night: bool):
        x = int(width * 0.85)
        y = int(height * 0.15)
        radius = 30
        
        if is_night:
            draw.ellipse([x-radius, y-radius, x+radius, y+radius], fill=(255, 255, 224))
            draw.ellipse([x-radius+10, y-radius-5, x+radius+10, y+radius-5], fill=None)
        else:
            draw.ellipse([x-radius, y-radius, x+radius, y+radius], fill=(255, 223, 0))
            for i in range(8):
                angle = i * 45 * math.pi / 180
                x1 = x + int((radius + 10) * math.cos(angle))
                y1 = y + int((radius + 10) * math.sin(angle))
                x2 = x + int((radius + 20) * math.cos(angle))
                y2 = y + int((radius + 20) * math.sin(angle))
                draw.line([(x1, y1), (x2, y2)], fill=(255, 223, 0), width=3)
    
    def _draw_ground(self, draw: ImageDraw.Draw, width: int, height: int, setting: str):
        ground_y = int(height * 0.7)
        
        if setting == "ocean":
            draw.rectangle([0, ground_y, width, height], fill=(0, 105, 148))
            for i in range(5):
                wave_y = ground_y + i * 20
                points = []
                for x in range(0, width, 10):
                    y_offset = int(5 * math.sin(x / 30 + i))
                    points.append((x, wave_y + y_offset))
                if len(points) > 1:
                    draw.line(points, fill=(255, 255, 255), width=2)
        elif setting == "desert":
            draw.rectangle([0, ground_y, width, height], fill=(237, 201, 175))
            for i in range(3):
                dune_points = [(0, height)]
                for x in range(0, width + 50, 50):
                    y = ground_y + int(30 * math.sin(x / 100 + i))
                    dune_points.append((x, y))
                dune_points.append((width, height))
                draw.polygon(dune_points, fill=(244, 164, 96))
        elif setting == "forest":
            draw.rectangle([0, ground_y, width, height], fill=(34, 139, 34))
            for _ in range(10):
                x = random.randint(0, width)
                y = random.randint(ground_y, height)
                draw.ellipse([x-3, y-3, x+3, y+3], fill=(0, 100, 0))
        else:
            draw.rectangle([0, ground_y, width, height], fill=(124, 179, 66))
    
    def _draw_characters(self, draw: ImageDraw.Draw, width: int, height: int, 
                         characters: List[str], seed: int):
        random.seed(seed)
        num_chars = min(len(characters), 4)
        if num_chars == 0:
            num_chars = 1
            characters = ["Figure"]
        
        ground_y = int(height * 0.7)
        spacing = width // (num_chars + 1)
        
        char_colors = [(139, 69, 19), (255, 218, 185), (210, 180, 140), 
                       (160, 82, 45), (255, 228, 196)]
        
        for i, char_name in enumerate(characters[:num_chars]):
            x = spacing * (i + 1)
            y = ground_y - 40
            
            color = char_colors[i % len(char_colors)]
            
            draw.ellipse([x-15, y-60, x+15, y-30], fill=color)
            
            draw.rectangle([x-20, y-30, x+20, y+30], fill=random.choice(self.styles["cartoon"]["colors"]))
            
            draw.line([(x-20, y-20), (x-40, y+10)], fill=color, width=5)
            draw.line([(x+20, y-20), (x+40, y+10)], fill=color, width=5)
            
            draw.line([(x-10, y+30), (x-15, y+60)], fill=(50, 50, 50), width=6)
            draw.line([(x+10, y+30), (x+15, y+60)], fill=(50, 50, 50), width=6)
            
            draw.ellipse([x-8, y-52, x-3, y-47], fill=(0, 0, 0))
            draw.ellipse([x+3, y-52, x+8, y-47], fill=(0, 0, 0))
    
    def _draw_scenery(self, draw: ImageDraw.Draw, width: int, height: int, 
                      setting: str, seed: int):
        random.seed(seed)
        ground_y = int(height * 0.7)
        
        if setting == "forest":
            for _ in range(8):
                x = random.randint(0, width)
                tree_height = random.randint(80, 150)
                trunk_width = random.randint(10, 20)
                
                draw.rectangle([x-trunk_width//2, ground_y-tree_height, 
                               x+trunk_width//2, ground_y], fill=(101, 67, 33))
                
                for j in range(3):
                    layer_y = ground_y - tree_height + j * 25
                    layer_width = 40 - j * 10
                    draw.polygon([(x, layer_y-30), (x-layer_width, layer_y+20), 
                                 (x+layer_width, layer_y+20)], fill=(34, 139, 34))
        
        elif setting == "mountain":
            for i in range(3):
                peak_x = random.randint(width//4, 3*width//4)
                peak_y = random.randint(height//4, height//3)
                base_width = random.randint(150, 250)
                
                draw.polygon([(peak_x, peak_y), 
                             (peak_x - base_width, ground_y),
                             (peak_x + base_width, ground_y)], 
                            fill=(105 + i*20, 105 + i*20, 105 + i*20))
                
                draw.polygon([(peak_x, peak_y),
                             (peak_x - 30, peak_y + 40),
                             (peak_x + 30, peak_y + 40)], fill=(255, 255, 255))
        
        elif setting == "city":
            for i in range(6):
                x = i * (width // 6) + random.randint(-20, 20)
                building_height = random.randint(100, 200)
                building_width = random.randint(40, 80)
                
                color = random.choice([(128, 128, 128), (169, 169, 169), (105, 105, 105)])
                draw.rectangle([x, ground_y - building_height, 
                               x + building_width, ground_y], fill=color)
                
                for wy in range(ground_y - building_height + 20, ground_y - 20, 25):
                    for wx in range(x + 10, x + building_width - 10, 20):
                        window_color = (255, 255, 0) if random.random() > 0.3 else (50, 50, 50)
                        draw.rectangle([wx, wy, wx+10, wy+15], fill=window_color)
        
        elif setting == "castle":
            castle_x = width // 2
            castle_width = 200
            castle_height = 180
            
            draw.rectangle([castle_x - castle_width//2, ground_y - castle_height,
                           castle_x + castle_width//2, ground_y], fill=(139, 69, 19))
            
            for tx in [-castle_width//2, castle_width//2 - 30]:
                draw.rectangle([castle_x + tx, ground_y - castle_height - 40,
                               castle_x + tx + 30, ground_y - castle_height], fill=(139, 69, 19))
                
                for cx in range(0, 30, 10):
                    draw.rectangle([castle_x + tx + cx, ground_y - castle_height - 50,
                                   castle_x + tx + cx + 5, ground_y - castle_height - 40], 
                                  fill=(139, 69, 19))
            
            draw.rectangle([castle_x - 20, ground_y - 60, castle_x + 20, ground_y], 
                          fill=(101, 67, 33))
            draw.arc([castle_x - 20, ground_y - 80, castle_x + 20, ground_y - 40], 
                    0, 180, fill=(101, 67, 33), width=40)
    
    def _add_scene_text(self, draw: ImageDraw.Draw, width: int, height: int, 
                        scene_id: int, description: str):
        try:
            font = ImageFont.truetype("/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf", 16)
            title_font = ImageFont.truetype("/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf", 20)
        except:
            font = ImageFont.load_default()
            title_font = font
        
        title = f"Scene {scene_id}"
        draw.rectangle([10, 10, 150, 40], fill=(0, 0, 0, 128))
        draw.text((15, 15), title, fill=(255, 255, 255), font=title_font)
        
        if description:
            short_desc = description[:80] + "..." if len(description) > 80 else description
            text_width = len(short_desc) * 8
            draw.rectangle([10, height - 50, min(text_width + 20, width - 10), height - 10], 
                          fill=(0, 0, 0, 180))
            draw.text((15, height - 45), short_desc, fill=(255, 255, 255), font=font)
    
    def generate_scene_image(self, scene: Dict[str, Any], style: str = "realistic",
                            width: int = 800, height: int = 600) -> str:
        style_config = self.styles.get(style, self.styles["realistic"])
        setting = self._detect_setting(scene)
        seed = self._get_deterministic_seed(scene.get("text", str(scene.get("id", 0))))
        
        colors = self.location_colors.get(setting, self.location_colors["default"])
        
        if style_config["bg_gradient"]:
            img = self._create_gradient_background(width, height, colors)
        else:
            img = Image.new('RGB', (width, height), colors[0])
        
        draw = ImageDraw.Draw(img)
        
        is_night = setting == "night" or "night" in scene.get("text", "").lower()
        self._draw_sun_or_moon(draw, width, height, is_night)
        
        self._draw_scenery(draw, width, height, setting, seed)
        
        self._draw_ground(draw, width, height, setting)
        
        characters = scene.get("characters", [])
        self._draw_characters(draw, width, height, characters, seed)
        
        self._add_scene_text(draw, width, height, scene.get("id", 1), 
                            scene.get("description", ""))
        
        if style_config["edge_softness"] > 0:
            img = img.filter(ImageFilter.GaussianBlur(radius=style_config["edge_softness"]))
        
        filename = f"scene_{scene.get('id', 1)}_{style}.png"
        filepath = os.path.join(self.output_dir, filename)
        img.save(filepath, "PNG")
        
        return filepath
    
    def generate_all_scenes(self, scenes: List[Dict[str, Any]], 
                           style: str = "realistic") -> List[str]:
        image_paths = []
        for scene in scenes:
            path = self.generate_scene_image(scene, style)
            image_paths.append(path)
        return image_paths
