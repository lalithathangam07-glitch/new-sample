document.addEventListener('DOMContentLoaded', function() {
    let currentSceneIdx = 0;
    let totalScenes = 0;
    let generationComplete = false;

    const storyText = document.getElementById('story-text');
    const btnSample = document.getElementById('btn-sample');
    const btnGenerate = document.getElementById('btn-generate');
    const btnAnalyze = document.getElementById('btn-analyze');
    const btnClear = document.getElementById('btn-clear');
    const btnPrev = document.getElementById('btn-prev');
    const btnNext = document.getElementById('btn-next');
    const sceneSelect = document.getElementById('scene-select');
    const loadingOverlay = document.getElementById('loading-overlay');
    const loadingText = document.getElementById('loading-text');
    const progressFill = document.getElementById('progress-fill');
    const toast = document.getElementById('toast');
    const artStyle = document.getElementById('art_style');
    const voiceOption = document.getElementById('voice_option');

    btnSample.addEventListener('click', loadSampleStory);
    btnGenerate.addEventListener('click', generateAllContent);
    btnAnalyze.addEventListener('click', analyzeStory);
    btnClear.addEventListener('click', clearAll);
    btnPrev.addEventListener('click', () => navigateScene(-1));
    btnNext.addEventListener('click', () => navigateScene(1));
    sceneSelect.addEventListener('change', () => loadScene(parseInt(sceneSelect.value)));

    document.querySelectorAll('.tab-btn').forEach(btn => {
        btn.addEventListener('click', () => switchTab(btn.dataset.tab));
    });

    document.querySelectorAll('.btn-generate-single').forEach(btn => {
        btn.addEventListener('click', () => generateSingleAsset(btn.dataset.type));
    });

    const analysisHeader = document.querySelector('.analysis-header');
    if (analysisHeader) {
        analysisHeader.addEventListener('click', toggleAnalysis);
    }

    artStyle.addEventListener('change', updateSettings);
    voiceOption.addEventListener('change', updateSettings);

    function showLoading(text = 'Processing...') {
        loadingText.textContent = text;
        progressFill.style.width = '0%';
        loadingOverlay.classList.remove('hidden');
    }

    function hideLoading() {
        loadingOverlay.classList.add('hidden');
    }

    function updateProgress(percent) {
        progressFill.style.width = percent + '%';
    }

    function showToast(message, type = 'success') {
        toast.textContent = message;
        toast.className = 'toast ' + type;
        toast.classList.remove('hidden');
        setTimeout(() => toast.classList.add('hidden'), 4000);
    }

    function loadSampleStory() {
        fetch('/load_sample', { method: 'POST' })
            .then(res => res.json())
            .then(data => {
                if (data.success) {
                    storyText.value = data.story;
                    showToast('Sample story loaded');
                }
            })
            .catch(err => showToast('Error loading sample', 'error'));
    }

    function analyzeStory() {
        const text = storyText.value.trim();
        if (!text) {
            showToast('Please enter a story first', 'error');
            return;
        }

        showLoading('Analyzing story...');

        const formData = new FormData();
        formData.append('story_text', text);

        fetch('/analyze', { method: 'POST', body: formData })
            .then(res => res.json())
            .then(data => {
                hideLoading();
                if (data.success) {
                    showAnalysis(data);
                    showToast(`Found ${data.scene_count} scenes!`);
                } else {
                    showToast(data.error, 'error');
                }
            })
            .catch(err => {
                hideLoading();
                showToast('Error analyzing story', 'error');
            });
    }

    function generateAllContent() {
        const text = storyText.value.trim();
        if (!text) {
            showToast('Please enter a story first', 'error');
            return;
        }

        showLoading('Starting generation...');
        updateProgress(5);

        const formData = new FormData();
        formData.append('story_text', text);
        formData.append('art_style', artStyle.value);
        formData.append('voice_option', voiceOption.value);

        let progressInterval = setInterval(() => {
            const current = parseInt(progressFill.style.width) || 0;
            if (current < 90) {
                updateProgress(current + 2);
            }
        }, 500);

        fetch('/generate', { method: 'POST', body: formData })
            .then(res => res.json())
            .then(data => {
                clearInterval(progressInterval);
                updateProgress(100);
                setTimeout(hideLoading, 500);

                if (data.success) {
                    totalScenes = data.scene_count;
                    generationComplete = true;
                    showAnalysis({ 
                        scene_count: totalScenes,
                        characters: data.characters || [],
                        locations: data.locations || []
                    });
                    setupSceneNavigator();
                    loadScene(0);
                    showResultsSection();
                    updateStats();
                    
                    if (data.errors && data.errors.length > 0) {
                        showToast(`Generated with ${data.errors.length} warning(s)`, 'warning');
                    } else {
                        showToast('All content generated successfully!');
                    }
                } else {
                    showToast(data.error, 'error');
                }
            })
            .catch(err => {
                clearInterval(progressInterval);
                hideLoading();
                showToast('Error generating content', 'error');
            });
    }

    function showAnalysis(data) {
        const section = document.getElementById('analysis-section');
        section.classList.remove('hidden');
        
        document.getElementById('analysis-scenes').textContent = data.scene_count || 0;
        document.getElementById('analysis-characters').textContent = (data.characters || []).length;
        document.getElementById('analysis-locations').textContent = (data.locations || []).length;
        
        document.getElementById('characters-list').textContent = 
            (data.characters || []).join(', ') || 'None detected';
        document.getElementById('locations-list').textContent = 
            (data.locations || []).join(', ') || 'None detected';
        
        document.getElementById('stat-scenes').textContent = data.scene_count || 0;
    }

    function toggleAnalysis() {
        const content = document.querySelector('.analysis-content');
        const icon = document.querySelector('.toggle-icon');
        content.classList.toggle('hidden');
        icon.textContent = content.classList.contains('hidden') ? '+' : '-';
    }

    function setupSceneNavigator() {
        sceneSelect.innerHTML = '';
        for (let i = 0; i < totalScenes; i++) {
            const option = document.createElement('option');
            option.value = i;
            option.textContent = `Scene ${i + 1}`;
            sceneSelect.appendChild(option);
        }
    }

    function showResultsSection() {
        document.getElementById('results-section').classList.remove('hidden');
        if (generationComplete) {
            document.getElementById('full-story-section').classList.remove('hidden');
            document.getElementById('download-section').classList.remove('hidden');
            loadFullAudio();
        }
    }

    function loadScene(idx) {
        if (idx < 0 || idx >= totalScenes) return;
        
        currentSceneIdx = idx;
        sceneSelect.value = idx;
        
        updateNavButtons();
        updateSceneProgress();

        fetch(`/scene/${idx}`)
            .then(res => res.json())
            .then(data => {
                if (data.success) {
                    renderScene(data);
                }
            })
            .catch(err => showToast('Error loading scene', 'error'));
    }

    function renderScene(data) {
        document.getElementById('scene-title').textContent = `Scene ${data.scene_id}`;
        document.getElementById('scene-text').textContent = data.scene.text || '';
        
        renderList('scene-characters', data.scene.characters || []);
        renderList('scene-locations', data.scene.locations || []);
        renderList('scene-actions', data.scene.actions || []);
        
        renderAsset('image', data.has_image, data.image_path, currentSceneIdx);
        renderAsset('3d', data.has_3d, data.render_3d_path, currentSceneIdx);
        renderAsset('animation', data.has_animation, data.animation_path, currentSceneIdx);
        renderAudio(data.has_audio, data.audio_path, currentSceneIdx);
    }

    function renderList(elementId, items) {
        const ul = document.getElementById(elementId);
        ul.innerHTML = '';
        if (items.length === 0) {
            ul.innerHTML = '<li style="color: var(--text-secondary);">None detected</li>';
        } else {
            items.slice(0, 5).forEach(item => {
                const li = document.createElement('li');
                li.textContent = item;
                ul.appendChild(li);
            });
        }
    }

    function renderAsset(type, hasAsset, path, sceneIdx) {
        const container = document.getElementById(type + '-container');
        
        if (hasAsset && path) {
            const isAnimation = type === 'animation';
            container.innerHTML = `
                <div style="text-align: center;">
                    <img src="/asset/${path.replace('output/', '')}" alt="Scene ${type}">
                    <br><br>
                    <a href="/download/${type}/${sceneIdx}" class="btn btn-secondary">Download ${type === '3d' ? '3D Render' : (isAnimation ? 'Animation (GIF)' : '2D Image')}</a>
                </div>
            `;
        } else {
            container.innerHTML = `<p class="placeholder-text">${type === '3d' ? '3D render' : (type === 'animation' ? 'Animation' : '2D image')} not generated yet.</p>`;
        }
    }

    function renderAudio(hasAudio, path, sceneIdx) {
        const container = document.getElementById('audio-container');
        
        if (hasAudio && path) {
            container.innerHTML = `
                <div style="width: 100%; text-align: center;">
                    <audio controls style="width: 100%; max-width: 500px;">
                        <source src="/asset/${path.replace('output/', '')}" type="audio/mp3">
                    </audio>
                    <br><br>
                    <a href="/download/audio/${sceneIdx}" class="btn btn-secondary">Download Scene Audio (MP3)</a>
                </div>
            `;
        } else {
            container.innerHTML = '<p class="placeholder-text">Audio narration not generated yet.</p>';
        }
    }

    function loadFullAudio() {
        const container = document.getElementById('full-audio-container');
        container.innerHTML = `
            <audio controls style="width: 100%;">
                <source src="/download/full_audio" type="audio/mp3">
            </audio>
        `;
    }

    function navigateScene(delta) {
        const newIdx = currentSceneIdx + delta;
        if (newIdx >= 0 && newIdx < totalScenes) {
            loadScene(newIdx);
        }
    }

    function updateNavButtons() {
        btnPrev.disabled = currentSceneIdx === 0;
        btnNext.disabled = currentSceneIdx >= totalScenes - 1;
    }

    function updateSceneProgress() {
        document.getElementById('scene-counter').textContent = 
            `Scene ${currentSceneIdx + 1} of ${totalScenes}`;
        const progress = ((currentSceneIdx + 1) / totalScenes) * 100;
        document.getElementById('scene-progress-fill').style.width = progress + '%';
    }

    function switchTab(tabName) {
        document.querySelectorAll('.tab-btn').forEach(btn => {
            btn.classList.toggle('active', btn.dataset.tab === tabName);
        });
        document.querySelectorAll('.tab-pane').forEach(pane => {
            pane.classList.toggle('active', pane.id === 'tab-' + tabName);
        });
    }

    function generateSingleAsset(type) {
        showLoading(`Generating ${type}...`);

        fetch(`/generate_single/${type}/${currentSceneIdx}`, { method: 'POST' })
            .then(res => res.json())
            .then(data => {
                hideLoading();
                if (data.success) {
                    loadScene(currentSceneIdx);
                    updateStats();
                    showToast(`${type} generated successfully!`);
                } else {
                    showToast(data.error, 'error');
                }
            })
            .catch(err => {
                hideLoading();
                showToast('Error generating asset', 'error');
            });
    }

    function updateStats() {
        fetch(`/scene/${currentSceneIdx}`)
            .then(res => res.json())
            .then(data => {
                let images = 0, audio = 0, renders = 0, animations = 0;
                
                for (let i = 0; i < totalScenes; i++) {
                    fetch(`/scene/${i}`)
                        .then(res => res.json())
                        .then(sceneData => {
                            if (sceneData.has_image) images++;
                            if (sceneData.has_audio) audio++;
                            if (sceneData.has_3d) renders++;
                            if (sceneData.has_animation) animations++;
                            
                            document.getElementById('stat-images').textContent = images;
                            document.getElementById('stat-audio').textContent = audio;
                            document.getElementById('stat-3d').textContent = renders;
                            document.getElementById('dl-images').textContent = images;
                            document.getElementById('dl-audio').textContent = audio;
                            document.getElementById('dl-3d').textContent = renders;
                            document.getElementById('dl-animations').textContent = animations;
                        });
                }
            });
    }

    function updateSettings() {
        const formData = new FormData();
        formData.append('art_style', artStyle.value);
        formData.append('voice_option', voiceOption.value);
        fetch('/settings', { method: 'POST', body: formData });
    }

    function clearAll() {
        fetch('/clear', { method: 'POST' })
            .then(res => res.json())
            .then(data => {
                if (data.success) {
                    storyText.value = '';
                    document.getElementById('analysis-section').classList.add('hidden');
                    document.getElementById('results-section').classList.add('hidden');
                    document.getElementById('full-story-section').classList.add('hidden');
                    document.getElementById('download-section').classList.add('hidden');
                    currentSceneIdx = 0;
                    totalScenes = 0;
                    generationComplete = false;
                    
                    document.getElementById('stat-scenes').textContent = '0';
                    document.getElementById('stat-images').textContent = '0';
                    document.getElementById('stat-audio').textContent = '0';
                    document.getElementById('stat-3d').textContent = '0';
                    
                    showToast('All cleared');
                }
            });
    }
});
