import re
from typing import List, Dict, Any, Optional
import hashlib


def clean_text(text: str) -> str:
    text = re.sub(r'\s+', ' ', text)
    text = text.strip()
    return text


def truncate_text(text: str, max_length: int = 100, suffix: str = "...") -> str:
    if len(text) <= max_length:
        return text
    return text[:max_length - len(suffix)] + suffix


def generate_hash(text: str, length: int = 8) -> str:
    return hashlib.md5(text.encode()).hexdigest()[:length]


def split_into_chunks(text: str, chunk_size: int = 500) -> List[str]:
    sentences = re.split(r'(?<=[.!?])\s+', text)
    chunks = []
    current_chunk = ""
    
    for sentence in sentences:
        if len(current_chunk) + len(sentence) <= chunk_size:
            current_chunk += " " + sentence if current_chunk else sentence
        else:
            if current_chunk:
                chunks.append(current_chunk.strip())
            current_chunk = sentence
    
    if current_chunk:
        chunks.append(current_chunk.strip())
    
    return chunks


def format_time_duration(seconds: float) -> str:
    if seconds < 60:
        return f"{int(seconds)}s"
    elif seconds < 3600:
        minutes = int(seconds // 60)
        secs = int(seconds % 60)
        return f"{minutes}m {secs}s"
    else:
        hours = int(seconds // 3600)
        minutes = int((seconds % 3600) // 60)
        return f"{hours}h {minutes}m"


def validate_story_input(text: str) -> Dict[str, Any]:
    result = {
        "valid": True,
        "errors": [],
        "warnings": [],
        "stats": {}
    }
    
    if not text or not text.strip():
        result["valid"] = False
        result["errors"].append("Story text cannot be empty")
        return result
    
    word_count = len(text.split())
    char_count = len(text)
    sentence_count = len(re.split(r'[.!?]+', text))
    
    result["stats"] = {
        "words": word_count,
        "characters": char_count,
        "sentences": sentence_count
    }
    
    if word_count < 10:
        result["warnings"].append("Story is very short. Consider adding more content for better scene generation.")
    
    if word_count > 5000:
        result["warnings"].append("Story is very long. Processing may take longer.")
    
    if not re.search(r'[.!?]', text):
        result["warnings"].append("No sentence endings detected. Consider adding proper punctuation.")
    
    return result


def extract_keywords(text: str, top_n: int = 10) -> List[str]:
    stop_words = {
        'the', 'a', 'an', 'and', 'or', 'but', 'in', 'on', 'at', 'to', 'for',
        'of', 'with', 'by', 'from', 'as', 'is', 'was', 'are', 'were', 'been',
        'be', 'have', 'has', 'had', 'do', 'does', 'did', 'will', 'would',
        'could', 'should', 'may', 'might', 'must', 'shall', 'can', 'need',
        'it', 'its', 'this', 'that', 'these', 'those', 'i', 'you', 'he',
        'she', 'we', 'they', 'me', 'him', 'her', 'us', 'them', 'my', 'your',
        'his', 'our', 'their', 'what', 'which', 'who', 'when', 'where', 'why',
        'how', 'all', 'each', 'every', 'both', 'few', 'more', 'most', 'other',
        'some', 'such', 'no', 'not', 'only', 'same', 'so', 'than', 'too',
        'very', 'just', 'also', 'now', 'here', 'there', 'then', 'once'
    }
    
    words = re.findall(r'\b[a-zA-Z]{3,}\b', text.lower())
    
    word_freq = {}
    for word in words:
        if word not in stop_words:
            word_freq[word] = word_freq.get(word, 0) + 1
    
    sorted_words = sorted(word_freq.items(), key=lambda x: x[1], reverse=True)
    
    return [word for word, _ in sorted_words[:top_n]]


def create_scene_prompt(scene: Dict[str, Any], style: str = "realistic") -> str:
    parts = []
    
    style_prefix = {
        "realistic": "Photorealistic scene:",
        "anime": "Anime-style illustration:",
        "cartoon": "Colorful cartoon scene:"
    }
    
    parts.append(style_prefix.get(style, "Scene:"))
    
    if scene.get("locations"):
        parts.append(f"Setting in {', '.join(scene['locations'][:2])}")
    
    if scene.get("characters"):
        parts.append(f"featuring {', '.join(scene['characters'][:3])}")
    
    if scene.get("actions"):
        parts.append(f"showing {', '.join(scene['actions'][:2])}")
    
    if scene.get("times"):
        parts.append(f"during {scene['times'][0]}")
    
    return " ".join(parts)


def sanitize_filename(filename: str) -> str:
    sanitized = re.sub(r'[^\w\s.-]', '', filename)
    sanitized = re.sub(r'\s+', '_', sanitized)
    return sanitized[:100]
