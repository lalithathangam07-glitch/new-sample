import os
import shutil
from typing import List, Optional, Dict, Any
import json
from datetime import datetime


def ensure_directory(path: str) -> bool:
    try:
        os.makedirs(path, exist_ok=True)
        return True
    except Exception as e:
        print(f"Error creating directory {path}: {e}")
        return False


def get_file_size(filepath: str) -> int:
    if os.path.exists(filepath):
        return os.path.getsize(filepath)
    return 0


def format_file_size(size_bytes: int) -> str:
    if size_bytes < 1024:
        return f"{size_bytes} B"
    elif size_bytes < 1024 * 1024:
        return f"{size_bytes / 1024:.1f} KB"
    elif size_bytes < 1024 * 1024 * 1024:
        return f"{size_bytes / (1024 * 1024):.1f} MB"
    else:
        return f"{size_bytes / (1024 * 1024 * 1024):.1f} GB"


def list_files_in_directory(directory: str, extension: Optional[str] = None) -> List[str]:
    if not os.path.exists(directory):
        return []
    
    files = []
    for filename in os.listdir(directory):
        filepath = os.path.join(directory, filename)
        if os.path.isfile(filepath):
            if extension is None or filename.endswith(extension):
                files.append(filepath)
    
    return sorted(files)


def delete_file(filepath: str) -> bool:
    try:
        if os.path.exists(filepath):
            os.remove(filepath)
            return True
        return False
    except Exception as e:
        print(f"Error deleting file {filepath}: {e}")
        return False


def copy_file(source: str, destination: str) -> bool:
    try:
        shutil.copy2(source, destination)
        return True
    except Exception as e:
        print(f"Error copying file: {e}")
        return False


def move_file(source: str, destination: str) -> bool:
    try:
        shutil.move(source, destination)
        return True
    except Exception as e:
        print(f"Error moving file: {e}")
        return False


def read_json_file(filepath: str) -> Optional[Dict[str, Any]]:
    try:
        with open(filepath, 'r', encoding='utf-8') as f:
            return json.load(f)
    except Exception as e:
        print(f"Error reading JSON file {filepath}: {e}")
        return None


def write_json_file(filepath: str, data: Dict[str, Any], indent: int = 2) -> bool:
    try:
        with open(filepath, 'w', encoding='utf-8') as f:
            json.dump(data, f, indent=indent, ensure_ascii=False)
        return True
    except Exception as e:
        print(f"Error writing JSON file {filepath}: {e}")
        return False


def read_text_file(filepath: str) -> Optional[str]:
    try:
        with open(filepath, 'r', encoding='utf-8') as f:
            return f.read()
    except Exception as e:
        print(f"Error reading text file {filepath}: {e}")
        return None


def write_text_file(filepath: str, content: str) -> bool:
    try:
        with open(filepath, 'w', encoding='utf-8') as f:
            f.write(content)
        return True
    except Exception as e:
        print(f"Error writing text file {filepath}: {e}")
        return False


def get_file_modification_time(filepath: str) -> Optional[datetime]:
    try:
        if os.path.exists(filepath):
            timestamp = os.path.getmtime(filepath)
            return datetime.fromtimestamp(timestamp)
        return None
    except Exception as e:
        print(f"Error getting modification time: {e}")
        return None


def cleanup_directory(directory: str, keep_extensions: Optional[List[str]] = None) -> int:
    deleted_count = 0
    
    if not os.path.exists(directory):
        return 0
    
    for filename in os.listdir(directory):
        filepath = os.path.join(directory, filename)
        
        if os.path.isfile(filepath):
            if keep_extensions:
                ext = os.path.splitext(filename)[1].lower()
                if ext in keep_extensions:
                    continue
            
            if delete_file(filepath):
                deleted_count += 1
    
    return deleted_count


def get_directory_size(directory: str) -> int:
    total_size = 0
    
    if not os.path.exists(directory):
        return 0
    
    for dirpath, dirnames, filenames in os.walk(directory):
        for filename in filenames:
            filepath = os.path.join(dirpath, filename)
            total_size += get_file_size(filepath)
    
    return total_size


def create_backup(source_dir: str, backup_dir: str) -> Optional[str]:
    try:
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        backup_name = f"backup_{timestamp}"
        backup_path = os.path.join(backup_dir, backup_name)
        
        ensure_directory(backup_dir)
        shutil.copytree(source_dir, backup_path)
        
        return backup_path
    except Exception as e:
        print(f"Error creating backup: {e}")
        return None


def get_unique_filename(directory: str, base_name: str, extension: str) -> str:
    filename = f"{base_name}{extension}"
    filepath = os.path.join(directory, filename)
    
    counter = 1
    while os.path.exists(filepath):
        filename = f"{base_name}_{counter}{extension}"
        filepath = os.path.join(directory, filename)
        counter += 1
    
    return filename
